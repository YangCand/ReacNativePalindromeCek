import React, { useState } from 'react';
import { View, TextInput, Button, Alert, ToastAndroid, Image,Text } from 'react-native';

export default function App() {
  const [inputText, setInputText] = useState('');
  const [isPalindrome, setIsPalindrome] = useState(false);

  const checkPalindrome = () => {
    // Menghapus karakter non-alfanumerik dan mengubah huruf menjadi huruf kecil
    const cleanText = inputText.replace(/[^A-Za-z0-9]/g, '').toLowerCase();
    
    // Memeriksa apakah string asli sama dengan string yang dibalik
    const isPalindrome = cleanText === cleanText.split('').reverse().join('');
    
    if (isPalindrome) {
      Alert.alert('Info', 'Kata tersebut adalah palindrom.');
      ToastAndroid.show('Kata tersebut adalah palindrom.', ToastAndroid.SHORT);
    } else {
      Alert.alert('Info', 'Kata tersebut bukan palindrom.');
      ToastAndroid.show('Kata tersebut bukan palindrom.', ToastAndroid.SHORT);
    }
  };

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor : 'yellow'}}>

        <Image
          style={{
            width: 160,
            height: 230,
          }}
          source={{ uri: 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgK-9tQSXIoYB3HqFmRikcc6dL9fXr4B04iSWgT43KsON0E1qZ5MvC_x7zt9CoG4gy6OCE5EuMqpdDZQucX-kB2W2_iz0z3YWPS1TzxSjfeAmeoE0unUBddjPTxIUUQuVccJ_LjNg9viPI/s1600/Gambar+Oddbods+Pogo+Kartun+Lucu+Wallpaper+Image.png' }}
        />
        
        <Text style={{ fontSize: 18, fontWeight: 'bold', marginTop:10, marginLeft: 50, marginRight: 50 ,textAlign : 'center'}}>
        Palindrom merupakan sebuah kata, bilangan, frasa, atau susunan karakter lain yang serupa jika dibaca dengan urutan terbalik ataupun tidak.
        </Text>
        <Text>
        contoh : "Kasur ini rusak"
        </Text>


      <TextInput
        style={{
          borderWidth: 1,
          borderColor: 'black',
          width: 200,
          height: 40,
          padding: 10,
          margin: 10,
          borderRadius: 10,
          backgroundColor : 'white',
        }}
        placeholder="Masukkan kata"
        value={inputText}
        onChangeText={setInputText}
      />

      <Button
        title="Cek Palindrome"
        onPress={checkPalindrome}
      />

    </View>
  );
}